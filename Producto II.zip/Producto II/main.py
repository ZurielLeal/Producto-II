import random
import string
import time
import tkinter as tk
from tkinter import ttk, messagebox

GENES = string.ascii_uppercase + string.ascii_lowercase + string.digits + " áéíóúÁÉÍÓÚñÑ.,-!?"


def crear_individuo(longitud):
    return [random.choice(GENES) for _ in range(longitud)]


def calcular_fitness(cromosoma, objetivo):
    aciertos = sum(1 for gen, obj in zip(cromosoma, objetivo) if gen == obj)
    return (aciertos / len(objetivo)) * 100.0


def seleccion_torneo(poblacion_eval, k=3):
    participantes = random.sample(poblacion_eval, min(k, len(poblacion_eval)))
    participantes.sort(key=lambda x: x[1], reverse=True)
    return participantes[0][0]


def cruzar(padre1, padre2):
    if len(padre1) < 2:
        return padre1[:], len(padre1) // 2
    punto = random.randint(1, len(padre1) - 1)
    return padre1[:punto] + padre2[punto:], punto


def mutar(cromosoma, tasa_mutacion):
    mutados = []
    genes_mutados = 0
    for gen in cromosoma:
        if random.random() < tasa_mutacion:
            mutados.append(random.choice(GENES))
            genes_mutados += 1
        else:
            mutados.append(gen)
    return mutados, genes_mutados


class SimuladorInteractivoAG:
    def __init__(self, root):
        self.root = root
        self.root.title("Simulador Interactivo - Búsqueda Evolutiva (Algoritmo Genético)")
        self.root.geometry("1220x710")
        self.root.configure(bg="#1e1e2e")

        self.reproduciendo = False
        self.job_after = None
        self.gen_actual = 0
        self.max_gen = 400
        self.poblacion = []
        self.historial = []
        self.inicio_t = 0.0
        self.ultimo_evento = ""

        self._construir_ui()
        self.inicializar_poblacion()

    def _construir_ui(self):
        estilo = ttk.Style()
        estilo.theme_use("clam")

        # Encabezado
        header = tk.Frame(self.root, bg="#181825", pady=10, padx=20)
        header.pack(fill="x")
        tk.Label(
            header,
            text="🧬 Simulador Interactivo de Búsqueda Evolutiva (Algoritmo Genético)",
            font=("Segoe UI", 15, "bold"),
            fg="#cdd6f4",
            bg="#181825",
        ).pack(anchor="w")
        tk.Label(
            header,
            text="Producto II - Unidad II | Selección, Cruce, Mutación y Convergencia en Tiempo Real",
            font=("Segoe UI", 9),
            fg="#a6adc8",
            bg="#181825",
        ).pack(anchor="w")

        # Barra de parámetros y botones
        ctrl = tk.Frame(self.root, bg="#24273a", padx=12, pady=10)
        ctrl.pack(fill="x", padx=14, pady=(10, 6))

        campos = [
            ("Objetivo:", "INTELIGENCIA ARTIFICIAL", 24, 0),
            ("Población:", "120", 6, 1),
            ("Mutación:", "0.04", 6, 2),
            ("Máx. Gen:", "400", 6, 3),
            ("Semilla:", "42", 6, 4),
        ]
        self.entradas = {}
        for etiqueta, val_def, ancho, col in campos:
            tk.Label(
                ctrl,
                text=etiqueta,
                bg="#24273a",
                fg="#cad3f5",
                font=("Segoe UI", 9, "bold"),
            ).grid(row=0, column=col, sticky="w", padx=(0, 6))
            ent = tk.Entry(ctrl, width=ancho, font=("Segoe UI", 10))
            ent.insert(0, val_def)
            ent.grid(row=1, column=col, padx=(0, 8), ipady=2)
            self.entradas[etiqueta] = ent

        tk.Label(
            ctrl,
            text="Velocidad (ms):",
            bg="#24273a",
            fg="#cad3f5",
            font=("Segoe UI", 9, "bold"),
        ).grid(row=0, column=5, sticky="w")
        self.scale_vel = tk.Scale(
            ctrl,
            from_=0,
            to=250,
            orient="horizontal",
            length=100,
            bg="#24273a",
            fg="#cdd6f5",
            highlightthickness=0,
            troughcolor="#11111b",
        )
        self.scale_vel.set(10)
        self.scale_vel.grid(row=1, column=5, padx=(0, 8))

        # Botones de control y acceso rápido
        btns = tk.Frame(ctrl, bg="#24273a")
        btns.grid(row=1, column=6, padx=2)

        self.btn_play = tk.Button(
            btns,
            text="▶ Reproducir",
            command=self.alternar_reproduccion,
            bg="#a6e3a1",
            fg="#11111b",
            font=("Segoe UI", 9, "bold"),
            relief="flat",
            padx=8,
            pady=5,
            cursor="hand2",
        )
        self.btn_play.pack(side="left", padx=2)

        self.btn_paso = tk.Button(
            btns,
            text="⏭ +1 Gen",
            command=self.paso_manual,
            bg="#89b4fa",
            fg="#11111b",
            font=("Segoe UI", 9, "bold"),
            relief="flat",
            padx=8,
            pady=5,
            cursor="hand2",
        )
        self.btn_paso.pack(side="left", padx=2)

        self.btn_25 = tk.Button(
            btns,
            text="⚡ +25 Gen",
            command=lambda: self.avanzar_lote(25),
            bg="#cba6f7",
            fg="#11111b",
            font=("Segoe UI", 9, "bold"),
            relief="flat",
            padx=8,
            pady=5,
            cursor="hand2",
        )
        self.btn_25.pack(side="left", padx=2)

        self.btn_fin = tk.Button(
            btns,
            text="🚀 Ir al Final",
            command=self.ir_al_final,
            bg="#f9e2af",
            fg="#11111b",
            font=("Segoe UI", 9, "bold"),
            relief="flat",
            padx=8,
            pady=5,
            cursor="hand2",
        )
        self.btn_fin.pack(side="left", padx=2)

        self.btn_reset = tk.Button(
            btns,
            text="↺ Reiniciar",
            command=self.inicializar_poblacion,
            bg="#f38ba8",
            fg="#11111b",
            font=("Segoe UI", 9, "bold"),
            relief="flat",
            padx=8,
            pady=5,
            cursor="hand2",
        )
        self.btn_reset.pack(side="left", padx=2)

        # Panel de estado actual
        estado = tk.Frame(self.root, bg="#24273a", padx=14, pady=8)
        estado.pack(fill="x", padx=14, pady=4)

        self.lbl_mejor = tk.Label(
            estado,
            text="Mejor individuo: ---",
            font=("Consolas", 12, "bold"),
            fg="#a6e3a1",
            bg="#24273a",
        )
        self.lbl_mejor.pack(anchor="w")

        self.lbl_metricas = tk.Label(
            estado,
            text="Generación: 0 | Fitness Máx: 0.0% | Promedio: 0.0%",
            font=("Segoe UI", 9, "bold"),
            fg="#f9e2af",
            bg="#24273a",
        )
        self.lbl_metricas.pack(anchor="w", pady=(2, 0))

        self.lbl_operador = tk.Label(
            estado,
            text="Operadores evolutivos: ---",
            font=("Segoe UI", 9),
            fg="#cdd6f5",
            bg="#24273a",
        )
        self.lbl_operador.pack(anchor="w")

        # Cuerpo principal: izquierda gráfica + derecha muestra de población
        cuerpo = tk.Frame(self.root, bg="#1e1e2e")
        cuerpo.pack(fill="both", expand=True, padx=14, pady=(4, 14))

        izq = tk.Frame(cuerpo, bg="#24273a", padx=10, pady=10)
        izq.pack(side="left", fill="both", expand=True, padx=(0, 7))
        tk.Label(
            izq,
            text="📈 Evolución del Fitness (Verde = Mejor | Azul = Promedio)",
            bg="#24273a",
            fg="#cad3f5",
            font=("Segoe UI", 10, "bold"),
        ).pack(anchor="w", pady=(0, 6))
        self.canvas = tk.Canvas(izq, bg="#11111b", highlightthickness=0)
        self.canvas.pack(fill="both", expand=True)

        der = tk.Frame(cuerpo, bg="#24273a", padx=10, pady=10, width=410)
        der.pack(side="right", fill="both", padx=(7, 0))
        tk.Label(
            der,
            text="🧬 Top Individuos de la Generación Actual",
            bg="#24273a",
            fg="#cad3f5",
            font=("Segoe UI", 10, "bold"),
        ).pack(anchor="w", pady=(0, 6))

        cols = ("rank", "fit", "cromosoma")
        self.tree = ttk.Treeview(der, columns=cols, show="headings", height=18)
        self.tree.heading("rank", text="#")
        self.tree.heading("fit", text="Fitness")
        self.tree.heading("cromosoma", text="Individuo (Cromosoma)")
        self.tree.column("rank", width=35, anchor="center")
        self.tree.column("fit", width=70, anchor="center")
        self.tree.column("cromosoma", width=265, anchor="w")
        self.tree.pack(fill="both", expand=True)

    def _leer_parametros(self):
        objetivo = self.entradas["Objetivo:"].get()
        if not objetivo.strip():
            messagebox.showwarning("Dato faltante", "Escribe una frase o palabra objetivo.")
            return None
        try:
            pob = int(self.entradas["Población:"].get())
            mut = float(self.entradas["Mutación:"].get())
            max_gen = int(self.entradas["Máx. Gen:"].get())
            sem = int(self.entradas["Semilla:"].get())
            if pob < 10 or max_gen < 1 or not (0.0 <= mut <= 1.0):
                raise ValueError
            return objetivo, pob, mut, max_gen, sem
        except ValueError:
            messagebox.showerror(
                "Parámetros inválidos",
                "Usa: Población >= 10, Mutación entre 0 y 1, Máx. Gen >= 1, Semilla entera.",
            )
            return None

    def pausar(self):
        self.reproduciendo = False
        self.btn_play.config(text="▶ Reproducir", bg="#a6e3a1")
        if self.job_after is not None:
            self.root.after_cancel(self.job_after)
            self.job_after = None

    def alternar_reproduccion(self):
        if self.reproduciendo:
            self.pausar()
        else:
            params = self._leer_parametros()
            if params is None:
                return
            if self.gen_actual == 0 or self.gen_actual >= self.max_gen:
                self.inicializar_poblacion(autostart=False)
            self.reproduciendo = True
            self.btn_play.config(text="⏸ Pausar", bg="#f9e2af")
            self._ciclo_animacion()

    def paso_manual(self):
        self.pausar()
        params = self._leer_parametros()
        if params is None:
            return
        if self.gen_actual == 0:
            self.inicializar_poblacion(autostart=False)
        self._avanzar_generacion(*params)

    def avanzar_lote(self, pasos):
        self.pausar()
        params = self._leer_parametros()
        if params is None:
            return
        if self.gen_actual == 0:
            self.inicializar_poblacion(autostart=False)
        objetivo, pob, mut, max_gen, sem = params
        for _ in range(pasos):
            if self._avanzar_generacion(objetivo, pob, mut, max_gen, sem, dibujar=False):
                break
        self._dibujar_grafica()

    def ir_al_final(self):
        self.pausar()
        params = self._leer_parametros()
        if params is None:
            return
        if self.gen_actual == 0:
            self.inicializar_poblacion(autostart=False)
        objetivo, pob, mut, max_gen, sem = params
        while self.gen_actual < max_gen:
            if self._avanzar_generacion(objetivo, pob, mut, max_gen, sem, dibujar=False):
                break
        self._dibujar_grafica()

    def inicializar_poblacion(self, autostart=False):
        self.pausar()
        params = self._leer_parametros()
        if params is None:
            return
        objetivo, pob, _, max_gen, sem = params
        random.seed(sem)

        self.max_gen = max_gen
        self.gen_actual = 0
        self.historial = []
        self.inicio_t = time.perf_counter()
        self.poblacion = [crear_individuo(len(objetivo)) for _ in range(pob)]
        self.ultimo_evento = "Población inicial aleatoria creada."

        pob_eval = sorted(
            [(ind, calcular_fitness(ind, objetivo)) for ind in self.poblacion],
            key=lambda x: x[1],
            reverse=True,
        )
        self._refrescar_vista(pob_eval, dibujar=True)

        if autostart:
            self.alternar_reproduccion()

    def _ciclo_animacion(self):
        if not self.reproduciendo:
            return
        params = self._leer_parametros()
        if params is None:
            self.pausar()
            return
        objetivo, pob, mut, max_gen, sem = params

        if self.gen_actual >= max_gen:
            self.pausar()
            return

        completado = self._avanzar_generacion(objetivo, pob, mut, max_gen, sem, dibujar=True)
        if completado:
            self.pausar()
            return

        demora = max(1, int(self.scale_vel.get()))
        self.job_after = self.root.after(demora, self._ciclo_animacion)

    def _avanzar_generacion(self, objetivo, pob, mut, max_gen, _, dibujar=True):
        if self.gen_actual >= max_gen:
            return True

        pob_eval = sorted(
            [(ind, calcular_fitness(ind, objetivo)) for ind in self.poblacion],
            key=lambda x: x[1],
            reverse=True,
        )
        mejor_ind, mejor_fit = pob_eval[0]
        prom_fit = sum(x[1] for x in pob_eval) / len(pob_eval)

        self.gen_actual += 1
        self.historial.append((self.gen_actual, mejor_fit, prom_fit))
        self._refrescar_vista(pob_eval, dibujar=dibujar)

        if mejor_fit >= 100.0:
            self.ultimo_evento = f"¡Objetivo alcanzado al 100% en la generación {self.gen_actual}!"
            self.lbl_operador.config(text=f"Estado: {self.ultimo_evento}")
            return True

        elitismo = 2
        nueva_pob = [x[0][:] for x in pob_eval[:elitismo]]
        p1 = seleccion_torneo(pob_eval, k=3)
        p2 = seleccion_torneo(pob_eval, k=3)
        punto_cruce = 0
        total_mutaciones = 0

        while len(nueva_pob) < pob:
            padre_a = seleccion_torneo(pob_eval, k=3)
            padre_b = seleccion_torneo(pob_eval, k=3)
            hijo, p_cruce = cruzar(padre_a, padre_b)
            hijo_mut, n_mut = mutar(hijo, mut)
            nueva_pob.append(hijo_mut)
            if padre_a is p1 or len(nueva_pob) == elitismo + 1:
                punto_cruce = p_cruce
            total_mutaciones += n_mut

        self.poblacion = nueva_pob
        self.ultimo_evento = (
            f"Torneo (k=3) + Cruce (punto {punto_cruce}) + "
            f"Mutación ({total_mutaciones} genes alterados)"
        )
        self.lbl_operador.config(text=f"Último ciclo: {self.ultimo_evento}")
        return False

    def _refrescar_vista(self, pob_eval, dibujar=True):
        mejor_ind, mejor_fit = pob_eval[0]
        prom_fit = sum(x[1] for x in pob_eval) / len(pob_eval)
        elapsed_ms = (time.perf_counter() - self.inicio_t) * 1000

        self.lbl_mejor.config(text=f"Mejor individuo: '{''.join(mejor_ind)}'")
        self.lbl_metricas.config(
            text=(
                f"Generación: {self.gen_actual}/{self.max_gen}   |   "
                f"Fitness Máx: {mejor_fit:.2f}%   |   "
                f"Promedio: {prom_fit:.2f}%   |   "
                f"Tiempo: {elapsed_ms:.1f} ms"
            )
        )
        self.lbl_operador.config(text=f"Último ciclo: {self.ultimo_evento}")

        for fila in self.tree.get_children():
            self.tree.delete(fila)
        for idx, (ind, fit) in enumerate(pob_eval[:20], start=1):
            self.tree.insert("", "end", values=(idx, f"{fit:.1f}%", "".join(ind)))

        if dibujar:
            self._dibujar_grafica()

    def _dibujar_grafica(self):
        self.canvas.delete("all")
        self.root.update_idletasks()

        w = max(self.canvas.winfo_width(), 350)
        h = max(self.canvas.winfo_height(), 250)
        pad_x, pad_y = 45, 22
        graf_w = max(w - pad_x * 2, 10)
        graf_h = max(h - pad_y * 2, 10)

        self.canvas.create_line(pad_x, pad_y, pad_x, h - pad_y, fill="#6c7086", width=2)
        self.canvas.create_line(pad_x, h - pad_y, w - pad_x, h - pad_y, fill="#6c7086", width=2)

        for pct in (0, 25, 50, 75, 100):
            y = (h - pad_y) - (pct / 100.0) * graf_h
            self.canvas.create_line(pad_x, y, w - pad_x, y, fill="#313244", dash=(3, 3))
            self.canvas.create_text(
                pad_x - 10, y, text=f"{pct}%", fill="#a6adc8", anchor="e", font=("Segoe UI", 8)
            )

        n = len(self.historial)
        if n < 2:
            return

        pts_mejor = []
        pts_prom = []
        for i, (_, m_fit, p_fit) in enumerate(self.historial):
            x = pad_x + (i / max(self.max_gen - 1, 1)) * graf_w
            y_m = (h - pad_y) - (m_fit / 100.0) * graf_h
            y_p = (h - pad_y) - (p_fit / 100.0) * graf_h
            pts_mejor.extend([x, y_m])
            pts_prom.extend([x, y_p])

        self.canvas.create_line(pts_prom, fill="#89b4fa", width=2, dash=(4, 2))
        self.canvas.create_line(pts_mejor, fill="#a6e3a1", width=2.5)


if __name__ == "__main__":
    root = tk.Tk()
    app = SimuladorInteractivoAG(root)
    root.mainloop()